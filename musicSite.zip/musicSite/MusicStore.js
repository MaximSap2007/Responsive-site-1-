const SBtn = document.querySelector(".search-btn");
const CBtn = document.querySelector(".cancel-btn");
const SBox = document.querySelector(".search-box");
const SInput = document.querySelector("input");

SBtn.onclick = () =>
    {
        SBox.classList.add("active");
        SInput.classList.add("active");
        SBtn.classList.add("active");
        CBox.classList.add("active");
    }
CBtn.onclick = () =>
    {
        SBox.classList.remove("active");
        SInput.classList.remove("active");
        SBtn.classList.remove("active");
        CBox.classList.remove("active");
    }